### v1.0.0
* Initial release
### v1.0.1
* Extreme Savings Variant (BT)
### v1.0.2
* Fixed Governer Locking on Performance
### v1.0.3
* Again Fixed Governer
### v2.0.0
* Cleaned Code
* Auto to Manual Config
* Added Saturation Boost Option
* Added Dex2Oat Option
* GMS Doze
* Fixed Governer Stuck on Default
* Removed BT Variant